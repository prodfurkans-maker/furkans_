import { Chat } from '@/components/chat'

export default function Page() {
  return (
    <main className="h-dvh bg-muted/50">
      <Chat />
    </main>
  )
}
